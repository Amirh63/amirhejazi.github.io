///Game of life
///Amir Hejazi
///Project # 5

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdlib>
#include <unistd.h>


using namespace std;
const int SIZE = 20;

/*****************************************
 *          Function Prototype           *
 *****************************************/
void initGrid(bool life[][SIZE]);
void readGrid(bool life[][SIZE]);
void printGrid(const bool life[][SIZE]);
void determineNextGen(bool life[][SIZE]);
void statisticInfo(const bool life[][SIZE], int);

/**=======================================
   =               Main Function         =
   =======================================**/
int main()
{
    system("color 1e");
    bool life[SIZE][SIZE];

    initGrid(life);             /// initializing the array
    readGrid(life);             /// open the file and reading the data from the file and saving it in the array
    printGrid(life);            /// displaying the contents of array
    statisticInfo(life,0);      /// calculating and displaying the statistical information related to the rows and columns of the array

    /// allowing the life for bacteria to proceed for 5 generation
    for (int count = 0; count < 5; count++)
    {
        determineNextGen(life);
        printGrid(life);
        statisticInfo(life,count+1);
    }

    return 0;
}

/*****************************************
 *          Function Definition          *
 *****************************************/

 /**
 reading the coordinates for array
 **/
void readGrid(bool life[][SIZE])
{
    ifstream infile("bacteria.txt");
    int row, col;

    infile >> row >> col;

    while (infile){
        life[row][col] = true;
        infile >> row >> col;
    }
    infile.close();
}

/**
Initializing the array
**/
void initGrid(bool life[][SIZE])
{
    for (int row = 0; row < SIZE; row++){
        for (int col = 0; col < SIZE; col++){
            life[row][col] = false;
        }
    }
}

/**
displaying the content of the array
**/
void printGrid(const bool life[][SIZE])
{
    cout << "  01234567890123456789" << endl;
    for (int row = 0; row < SIZE; row++){
        cout << setw(2) << row;
        for (int col = 0; col < SIZE; col++){
            if (life[row][col]){
                cout << "*";
                usleep(40000);
            } else {
                cout << " ";
            }
        }
        cout << endl;
    }
}

/**
Determining the next generation of life
**/
void determineNextGen(bool life[][SIZE])
{
    bool nextLife[SIZE][SIZE];
    int cellCounter;

    for (int row = 0; row < SIZE; row++)
    {
        for (int col = 0; col < SIZE; col++)
        {
            /// resetting the counter
            cellCounter = 0;
            /// checking the surrounding cell for life
            if((row-1)>=0 && life[row-1][col]==true)
                cellCounter++;
            if((row-1)>=0 && (col+1)<SIZE && life[row-1][col+1]==true)
                cellCounter++;
            if((col+1<SIZE) && life[row][col+1]==true)
                cellCounter++;
            if((row+1)<SIZE && (col+1)<SIZE && life[row+1][col+1]==true)
                cellCounter++;
            if((row+1)<SIZE && life[row+1][col]==true)
                cellCounter++;
            if((row+1)<SIZE && (col-1)>=0 && life[row+1][col-1]==true)
                cellCounter++;
            if((col-1)>=0 && life[row][col-1]==true)
                cellCounter++;
            if((row-1)>=0 && (col-1)>=0 && life[row-1][col-1]==true)
                cellCounter++;
            /// determining the next generation of life according to the rules
            if(life[row][col] == true)   /// if the cell is currently living
            {
                if(cellCounter == 0 || cellCounter ==1)
                    nextLife[row][col] = false;
                else if(cellCounter >= 4)
                    nextLife[row][col] = false;
                else if(cellCounter == 2 || cellCounter ==3)
                    nextLife[row][col] = true;
            }
            else                        /// if the cell is currently empty
            {
                if(cellCounter == 3)
                    nextLife[row][col]=true;
                else
                    nextLife[row][col]=false;
            }
        }
    }

    /// saving the contents of nextLife array into the life array
    for (int row=0; row<SIZE; row++)
    {
        for (int col=0; col<SIZE; col++)
        {
            life[row][col] = nextLife[row][col];
        }
    }
}

/**
calculating the statistics for the rows and columns of the grid cells
**/
void statisticInfo(const bool life[][SIZE], int count)
{
    /// displaying the generation iterations
    if (count !=0)
    {
        cout << "\nThe grid after " << count << " generations have passed.\n"
             << "(GENERATION #" <<count<<") GAME OF LIFE STATISTICS\n\n";
    }else
    {
        cout << "(ORIGINAL GRID) GAME OF LIFE STATISTICS \n\n";
    }

    /// calculating the number of living cells in row # 10
    int counter = 0;

    for (int col=0; col<SIZE; col++)
    {
        if(life[10][col]==true)
            counter++;
    }
    cout <<"Total alive in row 10    = " <<counter<<endl;

    /// calculating the number of living cells in column # 10
    counter=0;
    for (int row=0; row<SIZE; row++)
    {
        if(life[row][10]==true)
            counter++;
    }
    cout <<"Total alive in column 10 = " <<counter<<endl;

    /// calculating the number of dead cells in row # 16
    counter=0;
    for (int col=0; col<SIZE; col++)
    {
        if(life[16][col]==false)
            counter++;
    }
    cout <<"Total dead in row 16     = " <<counter<<endl;

    /// calculating the number of dead cells in column # 1
    counter=0;
    for (int row=0; row<SIZE; row++)
    {
        if(life[row][1]==false)
            counter++;
    }
    cout <<"Total dead in column 1   = " <<counter<<endl;

    /// calculating the number of living cells in the entire board
    counter=0;
    for (int row=0; row<SIZE; row++)
    {
        for (int col=0; col<SIZE; col++)
        {
            if(life[row][col]==true)
                counter++;
        }
    }
    cout <<"Total alive              = " <<counter<<endl;

    /// calculating the number of dead cells in the entire board
    counter=0;
    for (int row=0; row<SIZE; row++)
    {
        for (int col=0; col<SIZE; col++)
        {
            if(life[row][col]==false)
                counter++;
        }
    }
    cout <<"Total dead               = " <<counter<<endl<<endl;

}
